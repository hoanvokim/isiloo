<?php
/**
 * Created by IntelliJ IDEA.
 * User: hvo
 * Date: 22.08.18
 * Time: 16:44
 */
?>
<?php $this->load->view('webapp/tpl_header'); ?>
    <section class="all-news-area clearfix section_padding_100_70">
        <div class="container">
            <div class="row wow zoomIn" data-wow-delay="0.2s" style="vertical-align: center;">
                <br/><br/><br/>
                <h1>Cám ơn bạn "<?php echo $name; ?>" đã liên lạc với chúng tôi.</h1>
                <h5>Chúng tôi sẽ liên lạc với bạn sớm nhất có thể.</h5>
                <br/><br/><br/>
            </div>
        </div>
    </section>
<?php $this->load->view('webapp/tpl_footer'); ?>