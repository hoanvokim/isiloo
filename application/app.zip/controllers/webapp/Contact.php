<?php
/**
 * Created by IntelliJ IDEA.
 * User: hoanvo
 * Date: 10/18/18
 * Time: 12:33 AM
 */

class Contact extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }
}
